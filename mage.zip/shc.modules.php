<?php
error_reporting(0); 
ini_set('memory_limit','-1');
class Modules_Checker {

    public $max_requests;
    public $options;

    public $outstanding_requests;
    public $multi_handle;
    public function test(){
        echo "as";
    }
    public function readline($pesan){
        echo "[SHC CHECKER] ".$pesan;
        $answer =  rtrim( fgets( STDIN ));
        return $answer;
    }
    public function clean($string) {
        $string = preg_replace('/\s+/', '', $string);
        $string = str_replace('-', '', $string);
        return preg_replace('/[^A-Za-z0-9@._\-]/', '', $string); // Removes special chars.
    }
    public function __construct($in_max_requests = 100, $in_options = array()) {
        $this->max_requests = $in_max_requests;
        $this->options = $in_options;
        
        $this->outstanding_requests = array();
        $this->multi_handle = curl_multi_init();
    }
    public function __destruct() {
    	$this->finishAllRequests();
    }
    public function setMaxRequests($in_max_requests) {
        $this->max_requests = $in_max_requests;
    }
    
    public function setOptions($in_options) {

        $this->options = $in_options;
    }
    public function startRequest($url, $callback, $user_data = array(), $custom =null , $debug = false) {
        $ch = curl_init();
        if($debug){
            curl_setopt($ch, CURLOPT_HEADER, false);
        }
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT ,0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_COOKIEJAR,  getcwd().'/cookijem.txt');
        curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookijem.txt');
        if($custom['header']){
            curl_setopt($ch, CURLOPT_HTTPHEADER, $custom['header']);
        }
        if($custom['encode']){
            curl_setopt($ch, CURLOPT_ENCODING , "gzip");
        }
        if($custom['post']){
            if(is_array($custom['post'])){
                $query = http_build_query($custom['post']);
            }else{
                $query = $custom['post'];
            }
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $query);
        }
        
        curl_multi_add_handle($this->multi_handle, $ch);
        $ch_array_key = (int)$ch;
        $this->outstanding_requests[$ch_array_key] = array(
            'url'       => $url,
            'callback'  => $callback,
            'user_data' => $user_data,
        );
        $this->checkForCompletedRequests();
    }
    public function finishAllRequests() {
        $this->waitForOutstandingRequestsToDropBelow(1);
    }
    private function checkForCompletedRequests() {
	do {
		$mrc = curl_multi_exec($this->multi_handle, $active);
	} while ($mrc == CURLM_CALL_MULTI_PERFORM);

	while ($active && $mrc == CURLM_OK) {
		if (curl_multi_select($this->multi_handle) != -1) {
			do {
				$mrc = curl_multi_exec($this->multi_handle, $active);
			} while ($mrc == CURLM_CALL_MULTI_PERFORM);
		}
		else
			return;
	}
        while ($info = curl_multi_info_read($this->multi_handle)) {
        
            $ch = $info['handle'];
            $ch_array_key = (int)$ch;
            
            if (!isset($this->outstanding_requests[$ch_array_key])) {
                die("Error - handle wasn't found in requests: '$ch' in ".
                    print_r($this->outstanding_requests, true));
            }
            
            $request = $this->outstanding_requests[$ch_array_key];

            $url        = $request['url'];
            $content    = curl_multi_getcontent($ch);
            $callback   = $request['callback'];
            $user_data  = $request['user_data'];

            call_user_func($callback, $content, $url, $ch, $user_data);
            
            unset($this->outstanding_requests[$ch_array_key]);
            
            curl_multi_remove_handle($this->multi_handle, $ch);
        }
    
    }
    private function waitForOutstandingRequestsToDropBelow($max)
    {
        while (1) {
            $this->checkForCompletedRequests();
            if (count($this->outstanding_requests)<$max)
            	break;
            
            usleep(10000);
        }
    }

}


?>
